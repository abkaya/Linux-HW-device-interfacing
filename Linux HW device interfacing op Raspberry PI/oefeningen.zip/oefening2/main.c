#include <stdio.h>

int main(void)
{
	int a;
	for (a=0;a<10;a++)
	{
		printf ("Hello world %d\r\n",a);
	}
	return 0;
}




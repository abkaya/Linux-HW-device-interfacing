#ifndef MAIN
#define MAIN

#endif
int pin;
pin=17;
int val;

/**
*
*
*/
void controlLed(FILE *file, int val);
